from hellopy.gameobject.sprite import *
from hellopy.window import *

__all__ = ['christmas_demo']

def christmas_demo():
    image(window.w/2,window.h/2,window.w,window.h,src='https://lldocs-1257261737.cos.ap-shanghai.myqcloud.com/Christmas.png')