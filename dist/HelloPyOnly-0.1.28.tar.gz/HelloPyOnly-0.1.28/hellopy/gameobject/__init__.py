from hellopy.gameobject.gameobject import *
from hellopy.gameobject.circle import *
from hellopy.gameobject.polygon import *
from hellopy.gameobject.rectangle import *
from hellopy.gameobject.triangle import *
from hellopy.gameobject.line import *
from hellopy.gameobject.text import *
from hellopy.gameobject.sprite import *
from hellopy.gameobject.ellipse import *
pygame.init()