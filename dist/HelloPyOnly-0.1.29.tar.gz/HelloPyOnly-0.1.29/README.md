# This is a Teaching Package for Only Edu.
# This is based on Pygame.
# Hello Coding!
